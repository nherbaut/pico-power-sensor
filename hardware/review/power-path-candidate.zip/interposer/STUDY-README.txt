COPPER STUDY ONLY. Not the authoritative interposer and not released.
Added PI_5V copper on both faces and 13 stitching vias. Parts/pinout unchanged.
DRC 0 violations/0 unconnected/0 parity. Complete voltage-loss target remains open.
No Gerbers, fabrication authorization or bench measurements.
